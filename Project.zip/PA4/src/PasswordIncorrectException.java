public class PasswordIncorrectException extends Exception {
}
